
from IPython.core.debugger import set_trace

import torch
import torch.nn as nn
import math
import numpy as np
import spectral_norm_fc
from collections import OrderedDict

criterion = nn.BCELoss()
sigmoid = nn.Sigmoid()


def _flatten(sequence):
    flat = [p.contiguous().view(-1) for p in sequence]
    return torch.cat(flat) if len(flat) > 0 else torch.tensor([])

class basic_net(nn.Module):
    def __init__(self, device="cuda", dim=2, z_dim=1, leaky=0.1, factor=512,spectral=False, coeff=1, separate=False):
        super().__init__()
        self.dim = dim
        self.factor = factor
        self.non_linear = nn.LeakyReLU(leaky) if leaky > 0 else nn.ReLU()
        self.separate = separate
        # TODO: init - it may affect the results.

        if spectral:
            ##self.l1 = nn.Sequential(nn.utils.spectral_norm(nn.Linear(dim, factor)))
            ##self.l2 = nn.Sequential(nn.utils.spectral_norm(nn.Linear(factor, factor)))
            ##self.l3 = nn.Sequential(nn.utils.spectral_norm(nn.Linear(factor, factor)))
            ##self.l4 = nn.Sequential(nn.utils.spectral_norm(nn.Linear(factor, z_dim)))

            #self.l1 = spectral_norm_fc(nn.Linear(dim, factor), coeff)
            #self.l2 = spectral_norm_fc(nn.Linear(factor, factor), coeff)
            #self.l3 = spectral_norm_fc(nn.Linear(factor, factor), coeff)
            #self.l4 = spectral_norm_fc(nn.Linear(factor, z_dim), coeff)
            if separate:
                seq = []
                for _ in range(z_dim):
                    seq.append(nn.Sequential(OrderedDict([
                    ('l1', spectral_norm_fc(nn.Linear(dim, factor), coeff)),
                    ('a1', self.non_linear),
                    ('l2', spectral_norm_fc(nn.Linear(factor, factor), coeff)),
                    ('a2', self.non_linear),
                    ('l3', spectral_norm_fc(nn.Linear(factor, factor), coeff)),
                    ('a3', self.non_linear),
                    ('l4', spectral_norm_fc(nn.Linear(factor, 1), coeff))
                    ])))
                self.seq = nn.ModuleList(seq)

            else:
                self.seq = nn.Sequential(OrderedDict([
                ('l1', spectral_norm_fc(nn.Linear(dim, factor), coeff)),
                ('a1', self.non_linear),
                ('l2', spectral_norm_fc(nn.Linear(factor, factor), coeff)),
                ('a2', self.non_linear),
                ('l3', spectral_norm_fc(nn.Linear(factor, factor), coeff)),
                ('a3', self.non_linear),
                ('l4', spectral_norm_fc(nn.Linear(factor, z_dim), coeff)),
                ]))

        else:
            if separate:
                seq = []
                for _ in range(z_dim):
                    seq.append(nn.Sequential(OrderedDict([
                    ('l1', nn.Linear(dim, factor)),
                    ('a1', self.non_linear),
                    ('l2', nn.Linear(factor, factor)),
                    ('a2', self.non_linear),
                    ('l3', nn.Linear(factor, factor)),
                    ('a3', self.non_linear),
                    ('l4', nn.Linear(factor, 1)),
                    ])))
                self.seq = nn.ModuleList(seq)

            else:
                self.seq = nn.Sequential(OrderedDict([
                    ('l1', nn.Linear(dim, factor)),
                    ('a1', self.non_linear),
                    ('l2', nn.Linear(factor, factor)),
                    ('a2', self.non_linear),
                    ('l3', nn.Linear(factor, factor)),
                    ('a3', self.non_linear),
                    ('l4', nn.Linear(factor, z_dim)),
                    ]))

        self.to(device)
        self.device = device

    def forward(self, x):
        if self.separate:
            z = [sub_seq(x) for sub_seq in self.seq]
            return torch.cat(z, dim=1)
        else:
            return self.seq(x)

    def cpu(self):
        super().cpu()
        self.device = "cpu"

    def cuda(self):
        super().cuda()
        self.device = "cuda"

