from IPython.core.debugger import set_trace

import torch
import numpy as np
import torch.nn as nn
from collections import OrderedDict
import math
'''
This is an implementation for the penalty term equation (20)

** Assume: the mono dim = the total input dim. i.e., q >= 0

--constants
n: mini-batch size
d: the number of monotone dim
q: the number of non-monotone dim
N: the number of nodes for numerical integration

--tensor
The whole data: n x (d+q) x d x N dim. Index : k x r x i x j  
X: n x (d+q) matrix. 
G_ri: n x (d+0) x d x N tensor. The gradient of (g1,...,gd) w.r.t. the input X's first d-dimensions.
weight: N-dimensional vector, i.e., size = (N,). The Clenshaw weight.
steps:: N-dimensional vector, should be iterable., i.e., size = (N,). The Clenshaw steps. from zero to 1.

--network
integrand: a "g".
integrands: a list of "g_i"s = [g1,...,gd]
'''
#device="cpu" #"cuda"
#d=2
#q=1
#n=100

#G_ri = torch.randn((n,d+0,d,N)).to(device)
#weight = torch.randn((N)).to(device)
#steps = torch.randn((N)).to(device)
#X = torch.randn((n,d+q)).to(device)
#offset=torch.zeros((1)).to(device)
#def integrands(X):
#    return torch.zeros((X.shape(0),d+0)).to(X.device)


def compute_cc_weights(nb_steps,device="cuda"):
    '''
    Code from UMNN.
    '''
    lam = np.arange(0, nb_steps + 1, 1).reshape(-1, 1)
    lam = np.cos((lam @ lam.T) * math.pi / nb_steps)
    lam[:, 0] = .5
    lam[:, -1] = .5 * lam[:, -1]
    lam = lam * 2 / nb_steps
    W = np.arange(0, nb_steps + 1, 1).reshape(-1, 1)
    W[np.arange(1, nb_steps + 1, 2)] = 0
    W = 2 / (1 - W ** 2)
    W[0] = 1
    W[np.arange(1, nb_steps + 1, 2)] = 0
    cc_weights = torch.tensor(lam.T @ W).float().to(device)
    steps = torch.tensor(np.cos(np.arange(0, nb_steps + 1, 1).reshape(-1, 1) * math.pi / nb_steps)).float().to(device)

    return cc_weights, steps
def f_hat(data, integrands, nb_steps=100, return_grad=False, quadrature="clenshaw", d = 1,partial_mon=True):
    '''input arguments:
        integrands [g1,...,gd] : takes X=(-1,d+q) and outputs [(-1,1),(-1,1),...,(-1,1)] of length d.
        data: (n x d+q) = [X, eta]

        output: f_hat(X): (n)
                grad: n x (d+0) x d x N tensor. The gradient of (g1,...,gd) w.r.t. the input X's first d-dimension.
                weight : weight used to get the clenshaw
    '''
    device = data.device

    if quadrature == "clenshaw":
        weight, steps = compute_cc_weights(nb_steps-1, device=device)
    else:
        steps, weight= np.polynomial.legendre.leggauss(nb_steps)
        weight = torch.tensor(weight).float().view(-1, 1).to(device)
        steps = torch.tensor(steps).float().view(-1, 1).to(device)
    steps = (steps+1)/2
    weight = weight/2
    #they return the input#step +1. Therefore, I substracted by -1 to get exactly nb_steps.
    #1) tX :
    if partial_mon:
        X, eta = data[:, :d], data[:, d:]
        tX = torch.transpose(torch.cat([step * X.unsqueeze(2) for step in steps], dim=2), 1, 2).reshape(-1, d)
        #For etas, I use trick: do not multiply anything but repeat. so step is not really used.
        etas = torch.transpose(torch.cat([eta.unsqueeze(2) for step in steps], dim=2), 1, 2).reshape(-1,data.shape[1]-d)
        output_list = integrands(torch.cat([tX,etas], dim =1)) # list of (nN,1) tensors
    else:
        X = data
        tX = torch.transpose(torch.cat([step*X.unsqueeze(2) for step in steps], dim = 2),1,2).reshape(-1,d)
        ## IMPORTANT: I stacked on dim=1. so that (n x N x d).view(-1,d) will preserve each observation as one.
        output_list = integrands(tX)  # list of (nN,1) tensors
    #2) g(x_steps)
    output = torch.cat([o.unsqueeze(1) for o in output_list], dim=2) #(nN, 1, d) # checked
    output = output.view(-1, nb_steps, len(output_list)) # check if right: n x N x d.
    #3) numerical integration
    integrated = (output * weight.view(1,-1, 1)).sum(dim=1) # sum over j: result = (n x d).
    f_hat = (X*integrated).sum(dim=1) #TODO: check f_hat is (n)

    if return_grad:
        grads = []
        for p in output_list:
            gradients = torch.autograd.grad(outputs=p,
                                            inputs=tX,
                                            grad_outputs=torch.ones(p.shape, device=device),
                                            create_graph=True, retain_graph=True)[0]
            grads.append(gradients.view(-1, 1, X.shape[1]))
        grad = torch.cat(grads, dim=1).view(X.shape[0], -1, len(output_list), X.shape[1]).permute(0, 2, 3, 1)
        return f_hat, (grad,weight)
    return f_hat,None

def penalty(G_ri, weight, X, reduction = "sum"):
    '''input arguments:
        The whole data: n x d x d x N dim. Index : k x r x i x j
        X: n x d matrix. Future: d should be d+q for a general q.
        G_ri: n x d x d x N tensor. The gradient of (g1,...,gd) w.r.t. the input X
        weight: N-dimensional vector, i.e., size = (N,). The Clenshaw weight.
    '''
    diff = G_ri - torch.transpose(G_ri,dim0=1, dim1=2) #n x d x d x N tensor
    weighted_diff = diff * weight.view(1,1,1,-1) #n x d x d x N tensor
    weighted_sum = weighted_diff.sum(dim=3) #n x d x d tensor. sum over index j
    x_weighted = weighted_sum * X.view(-1,X.shape[1],1) #n x d x d tensor
    x_weighted_sum = x_weighted.sum(dim=1).pow(2) # n x d tensor. sum over index r.
    x_penalty = x_weighted_sum.sum(dim=1) # n vector, sum over index i.

    if reduction =="sum":
        return x_penalty.sum() # a constant. size = (1,). sum over index k.
    else:
        return x_penalty


class mono_net(nn.Module):
    def __init__(self, device="cuda", dim=2, leaky=0.1, factor=20,
                 spectral=False, coeff=1,  mon=[+1, 1],factor2 = 128):
        super().__init__()
        self.dim = dim
        self.factor = factor
        self.non_linear = nn.LeakyReLU(leaky) if leaky > 0 else nn.ReLU()
        self.mon = mon
        self.pos_non_linear = nn.ELU()
        self.d = len(mon)

        if self.dim > self.d:
            self.partial_mon = True
        elif self.dim == self.d:
            self.partial_mon = False
        else:
            raise NotImplementedError
        if self.partial_mon:
            self.offset_net = nn.Sequential(OrderedDict([
                    ('l1', nn.Linear(dim, factor2)),
                    ('a1', self.non_linear),
                    ('l2', nn.Linear(factor2, factor2)),
                    ('a2', self.non_linear),
                    ('l3', nn.Linear(factor2, factor2)),
                    ('a3', self.non_linear),
                    ('l4', nn.Linear(factor2, 1)),
                    ]))
        else:
            self.register_parameter(name='offset_const', param=nn.Parameter(torch.randn(1).to(device)))

        seq = []
        if self.d>0:
            if spectral:
                for _ in range(self.d):
                    seq.append(nn.Sequential(OrderedDict([
                    ('l1', spectral_norm_fc(nn.Linear(dim, factor), coeff)),
                    ('a1', self.non_linear),
                    ('l2', spectral_norm_fc(nn.Linear(factor, factor), coeff)),
                    ('a2', self.non_linear),
                    ('l3', spectral_norm_fc(nn.Linear(factor, factor), coeff)),
                    ('a3', self.non_linear),
                    ('l4', spectral_norm_fc(nn.Linear(factor, 1), coeff))
                    ])))
                self.seq = nn.ModuleList(seq)

            else:
                for _ in range(self.d):
                    seq.append(nn.Sequential(OrderedDict([
                    ('l1', nn.Linear(dim, factor)),
                    ('a1', self.non_linear),
                    ('l2', nn.Linear(factor, factor)),
                    ('a2', self.non_linear),
                    ('l3', nn.Linear(factor, factor)),
                    ('a3', self.non_linear),
                    ('l4', nn.Linear(factor, 1)),
                    ])))
                self.seq = nn.ModuleList(seq)

        self.to(device)
        self.device = device
    def list_forward(self, X):
        Z = [sub_seq(X) for sub_seq in self.seq]
        for i, z in enumerate(Z):
            #set_trace()
            Z[i] = (self.pos_non_linear(z) + 1) * self.mon[i]
        return Z
    def offset(self,data):
        if self.partial_mon:
            X, eta = data[:, :self.d], data[:, self.d:]
            return self.offset_net(torch.cat([X*0, eta], dim=1))
        else:
            return self.offset_const
    def forward(self, data, return_grad=False, nb_steps=100,quadrature="clenshaw"):
        if self.d==0:
            if return_grad:
                return self.offset_net(data).view(-1),None
            else:
                return self.offset_net(data).view(-1)
        out,grad_weight = f_hat(data, self.list_forward, nb_steps=nb_steps,
                    return_grad=return_grad, quadrature=quadrature, d= self.d,
                    partial_mon=self.partial_mon)
        if return_grad:
            return out + self.offset(data).view(-1), grad_weight
        return out + self.offset(data).view(-1)
    def penalty(self, G_ri, weight, X, reduction="sum"):
        return penalty(G_ri, weight, X, reduction)

    def cpu(self):
        super().cpu()
        self.device = "cpu"

    def cuda(self):
        super().cuda()
        self.device = "cuda"


