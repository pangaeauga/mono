Monotone project repository.

For mono: All necessary codes are contained in JK_mon_general_dim.py including the network architectures.
For baseline: only for the MLP, net.py and spectral_norm_fc.py (if spectral normalization is used) are used. 

For "/home/kim2712/Desktop/research/mono/..." in the ipynb files, please change it to your directory ".../mono/..."

The "Data" directory contains data preprocessing and visualization with UMAP.
